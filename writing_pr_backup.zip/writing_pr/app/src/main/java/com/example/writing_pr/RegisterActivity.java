package com.example.writing_pr;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 1;
    private static final int PICK_LOCATION = 2;

    private RadioGroup radioGroupCategory;
    private RadioButton radioButtonUsed;
    private EditText editTextPrice;
    private EditText editTextTitle;
    private EditText editTextContent;
    private Button buttonUploadPhoto;
    private Button buttonUploadLocation;
    private Button buttonCancel;
    private Button buttonUpload;

    private ActivityResultLauncher<Intent> mGetContent;
    private ActivityResultLauncher<Intent> mGetLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // View 참조
        radioGroupCategory = findViewById(R.id.radioGroupCategory);
        radioButtonUsed = findViewById(R.id.radioButtonUsed);
        editTextPrice = findViewById(R.id.editTextPrice);
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextContent = findViewById(R.id.editTextContent);
        buttonUploadPhoto = findViewById(R.id.buttonUploadPhoto);
        buttonUploadLocation = findViewById(R.id.buttonUploadLocation);
        buttonCancel = findViewById(R.id.buttonCancel);
        buttonUpload = findViewById(R.id.buttonUpload);

        // 초기 가격 입력 부분 비활성화
        editTextPrice.setEnabled(false);

        // 라디오버튼 선택 변경 이벤트 처리
        radioGroupCategory.setOnCheckedChangeListener((group, checkedId) -> {
            if(checkedId == R.id.radioButtonUsed) {
                // '중고거래' 선택 시 가격 입력 활성화
                editTextPrice.setEnabled(true);
            } else {
                // 그 외에는 가격 입력 비활성화 및 내용 초기화
                editTextPrice.setEnabled(false);
                editTextPrice.setText("");
            }
        });

        mGetContent = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        // 사진 선택 후 돌아온 경우 결과 처리
                        Uri uri = result.getData().getData();
                        // TODO: 선택한 사진을 imageView에 표시하는 등의 코드 작성
                    }
                });

        mGetLocation = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    // 위치 선택 후 돌아온 경우 결과 처리
                    // TODO: 사용자가 선택한 위치 정보를 처리하는 코드 작성
                });

        // 사진 업로드 버튼 클릭 이벤트 처리
        buttonUploadPhoto.setOnClickListener(view -> {
            // 갤러리로 이동
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            mGetContent.launch(intent);
        });

        // 위치 업로드 버튼 클릭 이벤트 처리
        buttonUploadLocation.setOnClickListener(view -> {
            // Google Maps로 이동
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="));
            mGetLocation.launch(intent);
        });
        // 취소 버튼 클릭 이벤트 처리
        buttonCancel.setOnClickListener(view -> {
            // 모든 입력항목 초기화
            radioGroupCategory.clearCheck();
            editTextPrice.setText("");
            editTextTitle.setText("");
            editTextContent.setText("");
            Toast.makeText(this, "모든 항목이 초기화되었습니다.", Toast.LENGTH_SHORT).show();
        });

        // 완료 버튼 클릭 이벤트 처리
        buttonUpload.setOnClickListener(view -> {
            // 여기에 글 업로드 처리 코드 작성
            // 예시: uploadPost();
        });
    }

    // onActivityResult, uploadPost 등 추가 메소드 작성
}